import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Game Routes
  app.post(api.games.submitResult.path, async (req, res) => {
    try {
      const input = api.games.submitResult.input.parse(req.body);
      const userId = "dev-user";
      
      const result = await storage.createGameResult({ ...input, userId });
      
      // AI Adaptation Logic (Fire and forget or await?)
      // We await it to update difficulty immediately
      await adaptDifficulty(userId, input.gameType, input.score);

      res.status(201).json(result);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.games.getHistory.path, async (req, res) => {
    const userId = "dev-user";
    const history = await storage.getGameResults(userId);
    res.json(history);
  });

  app.get(api.games.getDifficulty.path, async (req, res) => {
    const userId = "dev-user";
    const gameType = req.params.gameType;
    const settings = await storage.ensureDifficultySettings(userId);
    
    let level = 1;
    if (gameType === 'memory_match') level = settings.memoryLevel || 1;
    if (gameType === 'sequence') level = settings.sequenceLevel || 1;
    if (gameType === 'math') level = settings.mathLevel || 1;

    res.json({ level });
  });

  app.get(api.games.getAllStats.path, async (req, res) => {
    try {
      const stats = await storage.getAllUsersWithStats();
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  return httpServer;
}

async function adaptDifficulty(userId: string, gameType: string, score: number) {
  try {
    const settings = await storage.ensureDifficultySettings(userId);
    
    // Simple heuristic or AI? Let's use AI for "Machine Learning" requirement
    const prompt = `
      User just played '${gameType}'.
      Score: ${score} (0-100 scale usually).
      Current Levels: Memory=${settings.memoryLevel}, Sequence=${settings.sequenceLevel}, Math=${settings.mathLevel}.
      
      Should we increase, decrease, or keep the difficulty for this game type?
      Return JSON: { "action": "increase" | "decrease" | "keep" }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-5.1",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const decision = JSON.parse(response.choices[0].message.content || "{}");
    
    let updates: any = {};
    if (gameType === 'memory_match') {
      let level = settings.memoryLevel || 1;
      if (decision.action === 'increase') level++;
      if (decision.action === 'decrease') level = Math.max(1, level - 1);
      updates.memoryLevel = level;
    } else if (gameType === 'sequence') {
      let level = settings.sequenceLevel || 1;
      if (decision.action === 'increase') level++;
      if (decision.action === 'decrease') level = Math.max(1, level - 1);
      updates.sequenceLevel = level;
    } else if (gameType === 'math') {
      let level = settings.mathLevel || 1;
      if (decision.action === 'increase') level++;
      if (decision.action === 'decrease') level = Math.max(1, level - 1);
      updates.mathLevel = level;
    }

    if (Object.keys(updates).length > 0) {
      await storage.updateDifficulty(userId, updates);
    }
  } catch (error) {
    console.error("AI Adaptation failed:", error);
  }
}
