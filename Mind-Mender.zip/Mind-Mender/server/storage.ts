import { db } from "./db";
import {
  gameResults,
  difficultySettings,
  users,
  type InsertGameResult,
  type GameResult,
  type DifficultySetting,
  type User
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createGameResult(result: InsertGameResult): Promise<GameResult>;
  getGameResults(userId: string): Promise<GameResult[]>;
  getDifficulty(userId: string): Promise<DifficultySetting | undefined>;
  updateDifficulty(userId: string, levels: Partial<DifficultySetting>): Promise<DifficultySetting>;
  ensureDifficultySettings(userId: string): Promise<DifficultySetting>;
  getAllUsersWithStats(): Promise<(User & { results: GameResult[] })[]>;
}

export class DatabaseStorage implements IStorage {
  async createGameResult(result: InsertGameResult): Promise<GameResult> {
    const [saved] = await db.insert(gameResults).values(result).returning();
    return saved;
  }

  async getGameResults(userId: string): Promise<GameResult[]> {
    return await db.select()
      .from(gameResults)
      .where(eq(gameResults.userId, userId))
      .orderBy(desc(gameResults.playedAt));
  }

  async getDifficulty(userId: string): Promise<DifficultySetting | undefined> {
    const [settings] = await db.select()
      .from(difficultySettings)
      .where(eq(difficultySettings.userId, userId));
    return settings;
  }

  async ensureDifficultySettings(userId: string): Promise<DifficultySetting> {
    const existing = await this.getDifficulty(userId);
    if (existing) return existing;

    const [created] = await db.insert(difficultySettings)
      .values({ userId })
      .returning();
    return created;
  }

  async updateDifficulty(userId: string, levels: Partial<DifficultySetting>): Promise<DifficultySetting> {
    const [updated] = await db.update(difficultySettings)
      .set(levels)
      .where(eq(difficultySettings.userId, userId))
      .returning();
    return updated;
  }

  async getAllUsersWithStats(): Promise<(User & { results: GameResult[] })[]> {
    const allUsers = await db.select().from(users);
    const results = await Promise.all(
      allUsers.map(async (user) => {
        const userResults = await this.getGameResults(user.id);
        return { ...user, results: userResults };
      })
    );
    return results;
  }
}

export const storage = new DatabaseStorage();
