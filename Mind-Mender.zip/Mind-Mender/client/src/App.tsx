import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";

// Pages
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Profile from "@/pages/Profile";
import AdminDashboard from "@/pages/AdminDashboard";
import MemoryMatch from "@/pages/games/MemoryMatch";
import Sequence from "@/pages/games/Sequence";
import MathGame from "@/pages/games/MathGame";
import NotFound from "@/pages/not-found";

function Router() {
  const mockUser = { id: "dev-user", firstName: "Developer", isAdmin: true };

  return (
    <div className="min-h-screen bg-[#FDFBF7]">
      <Navigation />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/games" component={Home} />
          <Route path="/profile" component={Profile} />
          <Route path="/admin" component={AdminDashboard} />
          
          {/* Game Routes */}
          <Route path="/games/memory" component={MemoryMatch} />
          <Route path="/games/sequence" component={Sequence} />
          <Route path="/games/math" component={MathGame} />
          
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
