import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type CreateGameResultRequest } from "@shared/routes";
import { GameResult } from "@shared/schema";

// Game types
export type GameType = 'memory_match' | 'sequence' | 'math';

// GET /api/games/difficulty/:gameType
export function useGameDifficulty(gameType: GameType) {
  return useQuery({
    queryKey: ['difficulty', gameType],
    queryFn: async () => {
      const res = await fetch(`/api/games/difficulty/${gameType}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch difficulty");
      const data = await res.json();
      return data.level; // Returns number
    },
    staleTime: 0, // Always fetch fresh difficulty based on recent performance
  });
}

// POST /api/games/results
export function useSubmitGameResult() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (result: CreateGameResultRequest) => {
      const res = await fetch(api.games.submitResult.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(result),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to submit result");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['game-history'] });
      // Also invalidate difficulty as it might change based on this result
      queryClient.invalidateQueries({ queryKey: ['difficulty'] });
    },
  });
}

// GET /api/games/history
export function useGameHistory() {
  return useQuery({
    queryKey: ['game-history'],
    queryFn: async () => {
      const res = await fetch(api.games.getHistory.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.games.getHistory.responses[200].parse(await res.json());
    },
  });
}
