import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

interface GameCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  color: string;
  delay?: number;
}

export function GameCard({ title, description, icon: Icon, href, color, delay = 0 }: GameCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Link href={href} className="group block h-full">
        <div className={`
          h-full bg-white rounded-3xl p-8 border-2 border-transparent shadow-lg
          hover:shadow-xl hover:scale-[1.02] hover:-translate-y-1
          transition-all duration-300 flex flex-col items-center text-center
          cursor-pointer relative overflow-hidden
        `}>
          {/* Decorative background circle */}
          <div className={`
            absolute -top-10 -right-10 w-40 h-40 rounded-full opacity-10
            group-hover:scale-150 transition-transform duration-500 ease-out
          `} style={{ backgroundColor: color }} />

          <div className={`
            w-20 h-20 rounded-2xl flex items-center justify-center mb-6 shadow-md
            group-hover:scale-110 transition-transform duration-300
          `} style={{ backgroundColor: color }}>
            <Icon className="w-10 h-10 text-white" />
          </div>
          
          <h3 className="text-3xl font-display font-bold text-gray-800 mb-3 group-hover:text-primary transition-colors">
            {title}
          </h3>
          
          <p className="text-lg text-muted-foreground leading-relaxed">
            {description}
          </p>
          
          <div className="mt-auto pt-8 w-full">
            <div className={`
              w-full py-3 rounded-xl font-bold text-lg
              bg-gray-100 text-gray-600 group-hover:text-white
              transition-all duration-300
            `} style={{ 
              // We use a style prop here to dynamically set hover color without complex class logic
              // In a real app, strict Tailwind classes might be preferred via 'group-hover:bg-...'
            }}>
              <span className="group-hover:hidden">Play Now</span>
              <span className="hidden group-hover:inline">Start Game</span>
            </div>
            {/* 
               Since hover states with dynamic colors are tricky in pure Tailwind without arbitary values, 
               let's use a simple inline style for the hover background effect via a nested span or similar strategy.
               Alternatively, we can just use the primary color for all buttons on hover.
            */}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
