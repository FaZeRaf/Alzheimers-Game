import { useAuth } from "@/hooks/use-auth";
import { GameCard } from "@/components/GameCard";
import { Brain, Calculator, Grid, Trophy } from "lucide-react";
import { useGameHistory } from "@/hooks/use-games";
import { Link } from "wouter";

export default function Home() {
  const { user } = useAuth();
  const { data: history } = useGameHistory();

  // Calculate simple stats
  const totalGames = history?.length || 0;
  const recentScore = history?.[0]?.score || 0;

  return (
    <div className="space-y-12 pb-20">
      {/* Welcome Section */}
      <section className="bg-white rounded-3xl p-8 shadow-sm border border-border">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-primary mb-2">
              Welcome back, {user?.firstName || "Friend"}!
            </h1>
            <p className="text-xl text-muted-foreground">
              Ready to exercise your mind today? Choose a game below.
            </p>
          </div>
          
          <div className="flex gap-4">
            <div className="bg-orange-50 px-6 py-4 rounded-2xl text-center border border-orange-100">
              <div className="text-3xl font-bold text-orange-600">{totalGames}</div>
              <div className="text-sm font-medium text-orange-800 uppercase tracking-wide">Games Played</div>
            </div>
            <div className="bg-blue-50 px-6 py-4 rounded-2xl text-center border border-blue-100">
              <div className="text-3xl font-bold text-blue-600">{recentScore}</div>
              <div className="text-sm font-medium text-blue-800 uppercase tracking-wide">Last Score</div>
            </div>
          </div>
        </div>
      </section>

      {/* Game Selection Grid */}
      <section>
        <h2 className="text-3xl font-display font-bold text-gray-800 mb-8 flex items-center gap-3">
          <Trophy className="w-8 h-8 text-yellow-500" />
          Choose Your Activity
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <GameCard 
            title="Memory Match"
            description="Find matching pairs of cards. Improves short-term memory and concentration."
            icon={Grid}
            href="/games/memory"
            color="#0EA5E9" // Sky blue
            delay={0.1}
          />
          <GameCard 
            title="Sequence"
            description="Repeat the pattern of lights. Enhances visual memory and attention span."
            icon={Brain}
            href="/games/sequence"
            color="#F97316" // Orange
            delay={0.2}
          />
          <GameCard 
            title="Quick Math"
            description="Simple arithmetic problems. Keeps your calculation skills sharp and fast."
            icon={Calculator}
            href="/games/math"
            color="#10B981" // Emerald
            delay={0.3}
          />
        </div>
      </section>

      {/* Progress Teaser */}
      <section className="bg-primary/5 rounded-3xl p-8 border border-primary/10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-2xl font-bold text-primary mb-2">Track Your Progress</h3>
            <p className="text-lg text-muted-foreground max-w-xl">
              See how your skills are improving over time with easy-to-read charts and daily streaks.
            </p>
          </div>
          <Link href="/profile">
            <button className="bg-white text-primary border-2 border-primary hover:bg-primary hover:text-white px-8 py-3 rounded-xl font-bold text-lg transition-all shadow-sm">
              View My Stats
            </button>
          </Link>
        </div>
      </section>
    </div>
  );
}
