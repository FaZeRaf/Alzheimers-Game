import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@shared/routes";
import { Loader2, Users, Trophy, Activity } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: [api.games.getAllStats.path],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const totalPlayers = stats?.length || 0;
  const totalGames = stats?.reduce((acc: number, user: any) => acc + user.results.length, 0) || 0;
  const avgScore = totalGames > 0 
    ? Math.round(stats?.reduce((acc: number, user: any) => 
        acc + user.results.reduce((uAcc: number, r: any) => uAcc + r.score, 0), 0) / totalGames)
    : 0;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-display font-bold text-primary">Developer Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Total Players</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPlayers}</div>
          </CardContent>
        </Card>
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Games Played</CardTitle>
            <Activity className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalGames}</div>
          </CardContent>
        </Card>
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Avg Score</CardTitle>
            <Trophy className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgScore}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Player Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Games</TableHead>
                <TableHead>Last Played</TableHead>
                <TableHead className="text-right">High Score</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats?.map((user: any) => {
                const lastGame = user.results[0];
                const highScore = user.results.reduce((max: number, r: any) => Math.max(max, r.score), 0);
                return (
                  <TableRow key={user.id}>
                    <TableCell className="font-mono text-xs">{user.id}</TableCell>
                    <TableCell className="font-medium">{user.firstName || 'Anonymous'}</TableCell>
                    <TableCell>{user.results.length}</TableCell>
                    <TableCell>{lastGame ? new Date(lastGame.playedAt).toLocaleDateString() : 'Never'}</TableCell>
                    <TableCell className="text-right font-bold text-primary">{highScore}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}