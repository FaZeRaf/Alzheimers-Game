import { Button } from "@/components/ui/button";
import { Brain, Heart, Sparkles, UserPlus } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7]">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 pattern-grid-lg opacity-20" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="font-display font-bold text-primary mb-6 leading-tight">
                Keep Your Mind Sharp & <br/>
                <span className="text-secondary-foreground">Stay Active</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-10 leading-relaxed max-w-2xl mx-auto">
                Gentle, fun, and adaptive games designed specifically for seniors to improve memory and mental agility.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button 
                  onClick={handleLogin}
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-white text-xl px-10 py-8 rounded-2xl shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all"
                >
                  <UserPlus className="mr-3 w-6 h-6" />
                  Get Started for Free
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Features Grid */}
      <section className="py-20 bg-white shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: Brain,
                title: "Adaptive Difficulty",
                desc: "Our AI gently adjusts the challenge level to match your pace, ensuring it's never too hard or too easy.",
                color: "bg-blue-100 text-blue-600"
              },
              {
                icon: Sparkles,
                title: "Fun & Engaging",
                desc: "Enjoy clear, beautiful games like Memory Match and Sequence that feel like play, not work.",
                color: "bg-amber-100 text-amber-600"
              },
              {
                icon: Heart,
                title: "Track Your Health",
                desc: "See your progress over time with simple, easy-to-read charts that celebrate your daily wins.",
                color: "bg-red-100 text-red-600"
              }
            ].map((feature, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="flex flex-col items-center text-center"
              >
                <div className={`w-20 h-20 ${feature.color} rounded-3xl flex items-center justify-center mb-6 shadow-sm`}>
                  <feature.icon className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-3">{feature.title}</h3>
                <p className="text-lg text-muted-foreground leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Image Section - Calming Nature */}
      <section className="py-20 bg-secondary/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col md:flex-row">
            <div className="md:w-1/2 p-12 flex flex-col justify-center">
              <h2 className="text-4xl font-display font-bold text-primary mb-6">Designed with Care</h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                We believe technology should be accessible to everyone. Our interface uses:
              </p>
              <ul className="space-y-4">
                {[
                  "Large, readable text",
                  "High contrast colors",
                  "Simple, clear instructions",
                  "No rush or time limits"
                ].map((item, i) => (
                  <li key={i} className="flex items-center text-lg font-medium text-gray-700">
                    <div className="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center mr-4">
                      ✓
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:w-1/2 bg-gray-200 relative min-h-[400px]">
              {/* Unsplash image of a senior enjoying tablet */}
              <img 
                src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80" 
                alt="Senior person using a tablet happily" 
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
