import { useAuth } from "@/hooks/use-auth";
import { useGameHistory } from "@/hooks/use-games";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Trophy, Calendar, TrendingUp } from "lucide-react";
import { format } from "date-fns";

export default function Profile() {
  const { user } = useAuth();
  const { data: history, isLoading } = useGameHistory();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-pulse text-2xl text-primary font-bold">Loading your progress...</div>
      </div>
    );
  }

  // Process data for charts
  const chartData = history?.map(game => ({
    date: format(new Date(game.playedAt || new Date()), 'MMM d'),
    score: game.score,
    type: game.gameType,
  })).reverse().slice(-10); // Last 10 games

  return (
    <div className="space-y-12 pb-20">
      {/* Profile Header */}
      <section className="bg-white rounded-3xl p-8 shadow-sm border border-border">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center text-4xl text-white font-bold shadow-lg">
             {user?.firstName?.[0] || user?.email?.[0] || "U"}
          </div>
          <div className="text-center md:text-left">
            <h1 className="text-4xl font-display font-bold text-primary mb-2">
              {user?.firstName ? `${user.firstName} ${user.lastName || ''}` : 'My Profile'}
            </h1>
            <p className="text-xl text-muted-foreground">
              Member since {user?.createdAt ? format(new Date(user.createdAt), 'MMMM yyyy') : 'Recently'}
            </p>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-border flex items-center gap-6">
          <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center">
            <Trophy className="w-8 h-8 text-yellow-600" />
          </div>
          <div>
            <div className="text-3xl font-bold text-gray-900">{history?.length || 0}</div>
            <div className="text-muted-foreground font-medium">Games Played</div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-border flex items-center gap-6">
          <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center">
            <TrendingUp className="w-8 h-8 text-green-600" />
          </div>
          <div>
             {/* Simple highest score logic */}
            <div className="text-3xl font-bold text-gray-900">
              {history?.reduce((max, curr) => Math.max(max, curr.score), 0) || 0}
            </div>
            <div className="text-muted-foreground font-medium">Highest Score</div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-border flex items-center gap-6">
           <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center">
            <Calendar className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <div className="text-3xl font-bold text-gray-900">
              {history?.[0]?.playedAt ? format(new Date(history[0].playedAt), 'MMM d') : '-'}
            </div>
            <div className="text-muted-foreground font-medium">Last Played</div>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <section className="bg-white p-8 rounded-3xl shadow-sm border border-border">
        <h2 className="text-2xl font-bold text-primary mb-8">Performance History</h2>
        
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis 
                dataKey="date" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#6B7280', fontSize: 14 }}
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#6B7280', fontSize: 14 }}
              />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke="hsl(var(--primary))" 
                strokeWidth={4} 
                dot={{ r: 6, fill: "hsl(var(--primary))", strokeWidth: 2, stroke: "#fff" }}
                activeDot={{ r: 8 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* History List */}
      <section>
        <h2 className="text-2xl font-bold text-primary mb-6">Recent Games</h2>
        <div className="bg-white rounded-3xl shadow-sm border border-border overflow-hidden">
          {history?.slice(0, 5).map((game, i) => (
            <div key={game.id} className={`p-6 flex items-center justify-between ${i !== 0 ? 'border-t border-border' : ''}`}>
              <div>
                <div className="font-bold text-lg text-gray-900 capitalize">
                  {game.gameType.replace('_', ' ')}
                </div>
                <div className="text-muted-foreground">
                  {game.playedAt ? format(new Date(game.playedAt), 'PPP p') : ''}
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-xl text-primary">{game.score} pts</div>
                <div className="text-sm text-gray-500">Level {game.difficultyLevel}</div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
