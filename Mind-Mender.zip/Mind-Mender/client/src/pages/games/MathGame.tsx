import { useState, useEffect } from "react";
import { useGameDifficulty, useSubmitGameResult } from "@/hooks/use-games";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Check, Delete } from "lucide-react";
import { Link } from "wouter";

export default function MathGame() {
  const { data: difficulty = 1 } = useGameDifficulty('math');
  const submitResult = useSubmitGameResult();

  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [operator, setOperator] = useState<'+' | '-'>('+');
  const [answer, setAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [questionCount, setQuestionCount] = useState(1);
  const [feedback, setFeedback] = useState<'none' | 'correct' | 'wrong'>('none');

  const maxQuestions = 5;

  const generateProblem = () => {
    // Difficulty logic
    // 1: Adds up to 10
    // 2: Adds up to 20, includes subtraction
    // 3: Adds up to 50
    const maxSum = difficulty === 1 ? 10 : difficulty === 2 ? 20 : 50;
    const allowSubtract = difficulty >= 2;

    const op = allowSubtract && Math.random() > 0.5 ? '-' : '+';
    setOperator(op);

    if (op === '+') {
      const n1 = Math.floor(Math.random() * (maxSum / 2));
      const n2 = Math.floor(Math.random() * (maxSum / 2));
      setNum1(n1);
      setNum2(n2);
    } else {
      const n1 = Math.floor(Math.random() * maxSum);
      const n2 = Math.floor(Math.random() * n1); // Ensure positive result
      setNum1(n1);
      setNum2(n2);
    }
    setAnswer("");
    setFeedback("none");
  };

  useEffect(() => {
    generateProblem();
  }, [difficulty]);

  const handleInput = (num: number) => {
    if (answer.length < 3) {
      setAnswer(prev => prev + num);
    }
  };

  const handleBackspace = () => {
    setAnswer(prev => prev.slice(0, -1));
  };

  const checkAnswer = () => {
    const val = parseInt(answer);
    const correct = operator === '+' ? num1 + num2 : num1 - num2;

    if (val === correct) {
      setFeedback('correct');
      setScore(s => s + 100);
      setTimeout(() => {
        if (questionCount < maxQuestions) {
          setQuestionCount(c => c + 1);
          generateProblem();
        } else {
          finishGame();
        }
      }, 1000);
    } else {
      setFeedback('wrong');
      setTimeout(() => {
        setAnswer("");
        setFeedback("none");
      }, 1000);
    }
  };

  const finishGame = () => {
    submitResult.mutate({
      gameType: 'math',
      difficultyLevel: difficulty,
      score: score,
      durationSeconds: 60,
      userId: null,
    });
    // Redirect or show summary (simplified here)
    window.location.href = "/profile";
  };

  return (
    <div className="max-w-md mx-auto pb-20">
      <div className="flex items-center justify-between mb-8">
        <Link href="/games">
          <Button variant="ghost" className="gap-2 text-lg">
            <ArrowLeft className="w-6 h-6" /> Back
          </Button>
        </Link>
        <div className="text-xl font-bold text-primary">
          {questionCount} / {maxQuestions}
        </div>
      </div>

      <div className={`
        bg-white rounded-3xl p-8 shadow-lg border-4 text-center mb-8 transition-colors duration-300
        ${feedback === 'correct' ? 'border-green-400 bg-green-50' : 
          feedback === 'wrong' ? 'border-red-400 bg-red-50' : 'border-primary/20'}
      `}>
        <div className="text-6xl font-bold text-gray-800 font-mono tracking-wider flex items-center justify-center gap-4">
          <span>{num1}</span>
          <span className="text-primary">{operator}</span>
          <span>{num2}</span>
          <span>=</span>
          <span className={`min-w-[80px] border-b-4 ${answer ? 'border-gray-800' : 'border-gray-200 text-gray-300'}`}>
            {answer || "?"}
          </span>
        </div>
        
        {feedback === 'correct' && <div className="mt-4 text-2xl font-bold text-green-600 flex justify-center items-center gap-2"><Check /> Correct!</div>}
        {feedback === 'wrong' && <div className="mt-4 text-2xl font-bold text-red-600">Try Again</div>}
      </div>

      {/* Number Pad */}
      <div className="grid grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
          <button
            key={num}
            onClick={() => handleInput(num)}
            className="h-20 bg-white rounded-2xl shadow-md border-b-4 border-gray-200 active:border-b-0 active:translate-y-1 text-3xl font-bold text-primary hover:bg-gray-50 transition-all"
          >
            {num}
          </button>
        ))}
        <button onClick={handleBackspace} className="h-20 bg-red-50 rounded-2xl shadow-md border-b-4 border-red-100 text-red-500 flex items-center justify-center">
          <Delete className="w-8 h-8" />
        </button>
        <button onClick={() => handleInput(0)} className="h-20 bg-white rounded-2xl shadow-md border-b-4 border-gray-200 text-3xl font-bold text-primary">
          0
        </button>
        <button 
          onClick={checkAnswer} 
          disabled={!answer}
          className="h-20 bg-green-500 rounded-2xl shadow-md border-b-4 border-green-700 active:border-b-0 active:translate-y-1 text-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Check className="w-8 h-8" />
        </button>
      </div>
    </div>
  );
}
