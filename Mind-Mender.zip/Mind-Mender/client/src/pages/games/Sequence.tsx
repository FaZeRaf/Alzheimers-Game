import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useGameDifficulty, useSubmitGameResult } from "@/hooks/use-games";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Play, RefreshCw, Trophy } from "lucide-react";
import { Link } from "wouter";

const COLORS = [
  { id: 0, color: "bg-red-500", active: "bg-red-400", sound: "do" },
  { id: 1, color: "bg-blue-500", active: "bg-blue-400", sound: "re" },
  { id: 2, color: "bg-green-500", active: "bg-green-400", sound: "mi" },
  { id: 3, color: "bg-yellow-500", active: "bg-yellow-400", sound: "fa" },
];

export default function Sequence() {
  const { data: difficulty = 1 } = useGameDifficulty('sequence');
  const submitResult = useSubmitGameResult();

  const [sequence, setSequence] = useState<number[]>([]);
  const [playerInput, setPlayerInput] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeColor, setActiveColor] = useState<number | null>(null);
  const [gameState, setGameState] = useState<'idle' | 'showing' | 'playing' | 'won' | 'lost'>('idle');
  const [round, setRound] = useState(1);

  // Difficulty determines max rounds
  const maxRounds = 3 + difficulty; 

  const startNewGame = () => {
    setSequence([]);
    setPlayerInput([]);
    setRound(1);
    setGameState('idle');
    addToSequence([]);
  };

  const addToSequence = (currentSeq: number[]) => {
    const nextColor = Math.floor(Math.random() * 4);
    const newSeq = [...currentSeq, nextColor];
    setSequence(newSeq);
    setPlayerInput([]);
    setGameState('showing');
    playSequence(newSeq);
  };

  const playSequence = async (seq: number[]) => {
    // Wait a bit before starting
    await new Promise(r => setTimeout(r, 1000));

    for (const colorId of seq) {
      setActiveColor(colorId);
      // Play sound here if implemented
      await new Promise(r => setTimeout(r, 800)); // Visible duration
      setActiveColor(null);
      await new Promise(r => setTimeout(r, 300)); // Gap
    }
    setGameState('playing');
  };

  const handleColorClick = (id: number) => {
    if (gameState !== 'playing') return;

    setActiveColor(id);
    setTimeout(() => setActiveColor(null), 300);

    const newInput = [...playerInput, id];
    setPlayerInput(newInput);

    // Check if correct so far
    if (newInput[newInput.length - 1] !== sequence[newInput.length - 1]) {
      setGameState('lost');
      submitGame(false);
      return;
    }

    // Check if round complete
    if (newInput.length === sequence.length) {
      if (round >= maxRounds) {
        setGameState('won');
        submitGame(true);
      } else {
        setRound(r => r + 1);
        setGameState('showing'); // Block input
        setTimeout(() => addToSequence(sequence), 1000);
      }
    }
  };

  const submitGame = (won: boolean) => {
    const baseScore = won ? 1000 : round * 100;
    submitResult.mutate({
      gameType: 'sequence',
      difficultyLevel: difficulty,
      score: baseScore,
      durationSeconds: 60, // approximate
      userId: null,
    });
  };

  return (
    <div className="max-w-2xl mx-auto pb-20">
       {/* Header */}
       <div className="flex items-center justify-between mb-8">
        <Link href="/games">
          <Button variant="ghost" className="gap-2 text-lg">
            <ArrowLeft className="w-6 h-6" /> Back
          </Button>
        </Link>
        <div className="flex items-center gap-4">
          <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-border">
            <span className="text-muted-foreground uppercase text-xs font-bold tracking-wider block">Round</span>
            <span className="text-2xl font-bold text-primary">{round} / {maxRounds}</span>
          </div>
        </div>
      </div>

      <div className="text-center mb-10">
        <h1 className="text-4xl font-display font-bold text-primary">Sequence</h1>
        <p className="text-lg text-muted-foreground mt-2">Watch the pattern and repeat it.</p>
      </div>

      <div className="grid grid-cols-2 gap-6 max-w-[400px] mx-auto mb-10">
        {COLORS.map((btn) => (
          <button
            key={btn.id}
            onClick={() => handleColorClick(btn.id)}
            disabled={gameState !== 'playing' && gameState !== 'idle'}
            className={`
              aspect-square rounded-3xl shadow-lg transition-all duration-200
              ${activeColor === btn.id ? `${btn.active} scale-95 ring-4 ring-offset-2 ring-primary` : btn.color}
              ${gameState !== 'playing' ? 'opacity-90 cursor-default' : 'hover:scale-105 active:scale-95 cursor-pointer'}
            `}
          />
        ))}
      </div>

      <div className="text-center h-20">
        {gameState === 'idle' && (
          <Button onClick={startNewGame} size="lg" className="text-xl px-10 py-6 rounded-2xl shadow-xl">
            <Play className="mr-3 w-6 h-6" /> Start Game
          </Button>
        )}
        {gameState === 'showing' && (
          <p className="text-2xl font-bold text-primary animate-pulse">Watch carefully...</p>
        )}
        {gameState === 'playing' && (
          <p className="text-2xl font-bold text-green-600">Your turn!</p>
        )}
        {gameState === 'won' && (
          <div className="flex flex-col items-center">
             <h2 className="text-3xl font-display font-bold text-primary mb-4">You Won!</h2>
             <Button onClick={startNewGame} size="lg" className="bg-green-600 hover:bg-green-700 text-white">
                Play Again
             </Button>
          </div>
        )}
        {gameState === 'lost' && (
          <div className="flex flex-col items-center">
             <h2 className="text-3xl font-display font-bold text-destructive mb-4">Game Over</h2>
             <Button onClick={startNewGame} size="lg" variant="outline">
                Try Again
             </Button>
          </div>
        )}
      </div>
    </div>
  );
}
