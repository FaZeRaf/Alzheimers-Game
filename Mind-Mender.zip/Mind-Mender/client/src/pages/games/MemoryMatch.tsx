import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGameDifficulty, useSubmitGameResult } from "@/hooks/use-games";
import { Button } from "@/components/ui/button";
import { ArrowLeft, RefreshCw, Trophy } from "lucide-react";
import { Link } from "wouter";

// Icons for the cards
import { 
  Cat, Dog, Fish, Bird, 
  Apple, Banana, Cherry, Grape,
  Car, Bike, Bus, Plane,
  LayoutGrid
} from "lucide-react";

const ALL_ICONS = [
  Cat, Dog, Fish, Bird, 
  Apple, Banana, Cherry, Grape,
  Car, Bike, Bus, Plane
];

interface Card {
  id: number;
  iconId: number;
  isFlipped: boolean;
  isMatched: boolean;
}

export default function MemoryMatch() {
  const { data: difficulty = 1 } = useGameDifficulty('memory_match');
  const submitResult = useSubmitGameResult();
  
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [moves, setMoves] = useState(0);
  const [gameWon, setGameWon] = useState(false);
  const [startTime, setStartTime] = useState(Date.now());

  // Determine grid size based on difficulty
  // Level 1: 2x2 (4 cards)
  // Level 2: 3x2 (6 cards)
  // Level 3: 4x3 (12 cards)
  // Level 4+: 4x4 (16 cards)
  const getGridConfig = (level: number) => {
    if (level === 1) return { rows: 2, cols: 2, pairs: 2 };
    if (level === 2) return { rows: 2, cols: 3, pairs: 3 };
    if (level === 3) return { rows: 3, cols: 4, pairs: 6 };
    return { rows: 4, cols: 4, pairs: 8 };
  };

  const config = getGridConfig(difficulty);

  const initializeGame = () => {
    const selectedIcons = ALL_ICONS.slice(0, config.pairs);
    const deck = [...selectedIcons, ...selectedIcons]
      .map((_, index) => ({
        id: index,
        iconId: index % config.pairs,
        isFlipped: false,
        isMatched: false,
      }))
      .sort(() => Math.random() - 0.5);

    setCards(deck);
    setFlippedCards([]);
    setMoves(0);
    setGameWon(false);
    setIsProcessing(false);
    setStartTime(Date.now());
  };

  useEffect(() => {
    initializeGame();
  }, [difficulty]);

  const handleCardClick = (id: number) => {
    if (isProcessing || gameWon) return;
    
    const clickedCard = cards.find(c => c.id === id);
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return;

    // Flip the card
    const newCards = cards.map(c => c.id === id ? { ...c, isFlipped: true } : c);
    setCards(newCards);
    
    const newFlipped = [...flippedCards, id];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setIsProcessing(true);
      setMoves(m => m + 1);
      
      const [firstId, secondId] = newFlipped;
      const firstCard = newCards.find(c => c.id === firstId);
      const secondCard = newCards.find(c => c.id === secondId);

      if (firstCard?.iconId === secondCard?.iconId) {
        // Match found
        setTimeout(() => {
          setCards(prev => prev.map(c => 
            c.id === firstId || c.id === secondId 
              ? { ...c, isMatched: true, isFlipped: true } 
              : c
          ));
          setFlippedCards([]);
          setIsProcessing(false);
          
          // Check win condition
          if (newCards.filter(c => !c.isMatched).length === 2) {
            handleWin();
          }
        }, 500);
      } else {
        // No match
        setTimeout(() => {
          setCards(prev => prev.map(c => 
            c.id === firstId || c.id === secondId 
              ? { ...c, isFlipped: false } 
              : c
          ));
          setFlippedCards([]);
          setIsProcessing(false);
        }, 1500);
      }
    }
  };

  const handleWin = () => {
    setGameWon(true);
    const duration = Math.floor((Date.now() - startTime) / 1000);
    
    // Calculate score: Base 1000 - (moves * 10) - (duration * 2)
    const baseScore = 1000;
    const score = Math.max(100, baseScore - (moves * 10) - (duration * 2));

    submitResult.mutate({
      gameType: 'memory_match',
      difficultyLevel: difficulty,
      score,
      durationSeconds: duration,
      userId: null, // Backend handles user context from session
    });
  };

  return (
    <div className="max-w-4xl mx-auto pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <Link href="/games">
          <Button variant="ghost" className="gap-2 text-lg">
            <ArrowLeft className="w-6 h-6" /> Back
          </Button>
        </Link>
        <div className="flex items-center gap-4">
          <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-border">
            <span className="text-muted-foreground uppercase text-xs font-bold tracking-wider block">Level</span>
            <span className="text-2xl font-bold text-primary">{difficulty}</span>
          </div>
          <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-border">
            <span className="text-muted-foreground uppercase text-xs font-bold tracking-wider block">Moves</span>
            <span className="text-2xl font-bold text-secondary-foreground">{moves}</span>
          </div>
        </div>
      </div>

      <div className="text-center mb-8">
        <h1 className="text-4xl font-display font-bold text-primary">Memory Match</h1>
        <p className="text-lg text-muted-foreground mt-2">Find all the matching pairs!</p>
      </div>

      {/* Game Grid */}
      <div 
        className="grid gap-4 mx-auto max-w-[600px]"
        style={{ 
          gridTemplateColumns: `repeat(${config.cols}, 1fr)`,
          aspectRatio: `${config.cols}/${config.rows}`
        }}
      >
        <AnimatePresence>
          {cards.map((card) => {
            const Icon = ALL_ICONS[card.iconId];
            return (
              <motion.div
                key={card.id}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                whileHover={{ scale: card.isFlipped || card.isMatched ? 1 : 1.05 }}
                className="relative cursor-pointer aspect-square"
                onClick={() => handleCardClick(card.id)}
              >
                <div className={`
                  w-full h-full rounded-2xl transition-all duration-500 transform style-preserve-3d
                  ${card.isFlipped || card.isMatched ? 'rotate-y-180' : ''}
                `}>
                  {/* Card Back (Face Down) */}
                  <div className={`
                    absolute inset-0 bg-primary rounded-2xl shadow-md border-b-4 border-primary-foreground/20
                    flex items-center justify-center backface-hidden
                    ${card.isFlipped || card.isMatched ? 'opacity-0' : 'opacity-100'}
                  `}>
                    <LayoutGrid className="w-8 h-8 text-white/50" />
                  </div>

                  {/* Card Front (Face Up) */}
                  <div className={`
                    absolute inset-0 bg-white rounded-2xl shadow-lg border-2 
                    ${card.isMatched ? 'border-accent bg-accent/10' : 'border-secondary'}
                    flex items-center justify-center backface-hidden
                    ${card.isFlipped || card.isMatched ? 'opacity-100' : 'opacity-0'}
                  `}>
                    <Icon className={`w-1/2 h-1/2 ${card.isMatched ? 'text-accent' : 'text-primary'}`} />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Win Modal */}
      {gameWon && (
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
        >
          <motion.div 
            initial={{ scale: 0.8, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            className="bg-white rounded-3xl p-8 max-w-md w-full text-center shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary to-secondary" />
            
            <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-12 h-12 text-yellow-600" />
            </div>

            <h2 className="text-3xl font-display font-bold text-gray-900 mb-2">Excellent!</h2>
            <p className="text-lg text-muted-foreground mb-8">
              You completed the puzzle in {moves} moves.
            </p>

            <div className="flex flex-col gap-3">
              <Button 
                onClick={initializeGame}
                className="bg-primary hover:bg-primary/90 text-white h-14 text-lg rounded-xl shadow-lg"
              >
                <RefreshCw className="mr-2 w-5 h-5" />
                Play Again
              </Button>
              <Link href="/games">
                <Button variant="outline" className="h-12 text-lg rounded-xl border-2">
                  Choose Different Game
                </Button>
              </Link>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
