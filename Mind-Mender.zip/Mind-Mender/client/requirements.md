## Packages
recharts | Visualization for progress and stats
framer-motion | Smooth animations for game elements (card flips, transitions)
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Architects Daughter', cursive"],
  body: ["'DM Sans', sans-serif"],
  mono: ["'Fira Code', monospace"],
}
