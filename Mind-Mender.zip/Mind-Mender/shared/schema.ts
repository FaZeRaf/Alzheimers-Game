import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";
import { relations } from "drizzle-orm";

// Export integration schemas
export * from "./models/auth";
export * from "./models/chat";

// Game Results
export const gameResults = pgTable("game_results", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  gameType: text("game_type").notNull(), // 'memory_match', 'sequence', 'math'
  score: integer("score").notNull(),
  difficultyLevel: integer("difficulty_level").notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  playedAt: timestamp("played_at").defaultNow(),
});

// Difficulty Settings (AI Adapted)
export const difficultySettings = pgTable("difficulty_settings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id).unique(),
  memoryLevel: integer("memory_level").default(1),
  sequenceLevel: integer("sequence_level").default(1),
  mathLevel: integer("math_level").default(1),
  adaptationParams: jsonb("adaptation_params").$type<{
    recentPerformance: number[];
  }>().default({ recentPerformance: [] }),
});

export const insertGameResultSchema = createInsertSchema(gameResults).omit({ id: true, playedAt: true });
export const insertDifficultySchema = createInsertSchema(difficultySettings).omit({ id: true });

export type GameResult = typeof gameResults.$inferSelect;
export type InsertGameResult = z.infer<typeof insertGameResultSchema>;
export type DifficultySetting = typeof difficultySettings.$inferSelect;

export type CreateGameResultRequest = InsertGameResult;
