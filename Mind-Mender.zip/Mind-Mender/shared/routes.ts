import { z } from 'zod';
import { insertGameResultSchema, gameResults, difficultySettings } from './schema';

export const api = {
  games: {
    submitResult: {
      method: 'POST' as const,
      path: '/api/games/results',
      input: insertGameResultSchema,
      responses: {
        201: z.custom<typeof gameResults.$inferSelect>(),
        400: z.object({ message: z.string() }),
      },
    },
    getHistory: {
      method: 'GET' as const,
      path: '/api/games/history',
      responses: {
        200: z.array(z.custom<typeof gameResults.$inferSelect>()),
      },
    },
    getDifficulty: {
      method: 'GET' as const,
      path: '/api/games/difficulty/:gameType',
      responses: {
        200: z.object({ level: z.number() }),
      },
    },
    getAllStats: {
      method: 'GET' as const,
      path: '/api/admin/stats',
      responses: {
        200: z.array(z.any()),
      },
    },
  },
};

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};
